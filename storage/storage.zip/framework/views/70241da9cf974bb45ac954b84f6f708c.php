<table class="table">
    <thead>
        <tr>
            <th>kd_ruas</th>
            <th>Lintang</th>
            <th>Bujur</th>
            <th>Lokasi</th>
            <th>Keterangan</th>
            <th>Pelaporan</th>
            <th>Survei</th>
            <th>Selesai</th>
            <th>Rekomendasi</th>
            <th>Pelaksana</th>
            <th>Pelaksanaan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->slug); ?></td>
            <td><?php echo e(number_format($item->lat,4)); ?></td>
            <td><?php echo e(number_format($item->long,4)); ?></td>
            <td><?php echo e($item->loc_phnpt); ?></td>
            <td><?php echo e($item->alasan); ?></td>
            <td class="text-nowrap"><?php echo e($item->created_at->format('d/m/Y')); ?></td>
            <td class="text-nowrap"><?php echo e(date("d/m/Y",strtotime($item->tgl_survei))); ?></td>
            <td class="text-nowrap"><?php echo e($item->updated_at->format('d/m/Y')); ?></td>
            <td><?php echo e($item->survei); ?></td>
            <td><?php echo e($item->istansi); ?></td>
            <?php if($item->tgl_pelaksanaan): ?>
            <td><?php echo e(date("d/m/Y",strtotime($item->tgl_pelaksanaan))); ?></td>
            <?php else: ?>
            <td>Belum Melapor</td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $data1->links(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/tabledata.blade.php ENDPATH**/ ?>