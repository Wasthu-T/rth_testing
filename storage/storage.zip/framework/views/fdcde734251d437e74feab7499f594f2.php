

<?php $__env->startSection('container-user'); ?>
<h2 class="my-3 text-center">Rekapitulasi RTH</h2>
<div class="container my-5">
    <div class="table-responsive">
        <div id="data-container">
            <?php echo $__env->make('users.admin.tabledata', ['data1' => $data1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/datarekap.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/rekapitulasi.blade.php ENDPATH**/ ?>