

<!-- perhatikan lagi jika login dan tidak -->
<?php $__env->startSection('container-user'); ?>
<?php if(session()->has('berhasil')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('berhasil')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php elseif(session()->has('gagal')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('gagal')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<div class="mt-5">
    <h4>Data Diri</h4>
    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">Nomor Identitas</th>
                <td>: <?php echo e(auth()->user()->uuid); ?></td>
            </tr>
            <tr>
                <th scope="row">Username</th>
                <td>: <?php echo e(auth()->user()->username); ?></td>
            </tr>
            <tr>
                <th scope="row" class="col-4">Nama</th>
                <td class="col-8">: <?php echo e(auth()->user()->nm_lengkap); ?></td>
            </tr>
            <tr>
                <th scope="row">Alamat</th>
                <td>: <?php echo e(auth()->user()->alamat); ?></td>

            </tr>
            <tr>
                <th scope="row">Whatsapp</th>
                <td>: <?php echo e(auth()->user()->no_hp); ?></td>
            </tr>
            <tr>
                <th scope="row">Email</th>
                <td>: <?php echo e(auth()->user()->email); ?></td>
            </tr>
        </tbody>
    </table>
</div>


<a href="/dashboard/profil/ubah">
    <button type="button" class="btn btn-outline-warning">Ubah</button>
</a>

<?php if(auth()->user()->email_verified_at == null): ?>
<form class="d-inline" method="POST" action="<?php echo e(route('verification.send')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-link p-0 m-0 align-baseline">Verifikasi Email</button>.
</form>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/emailverif.blade.php ENDPATH**/ ?>