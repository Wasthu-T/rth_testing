

<!-- perhatikan lagi jika login dan tidak -->
<?php $__env->startSection('container-user'); ?>
<?php if(session()->has('berhasil')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('berhasil')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php elseif(session()->has('status')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('status')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php elseif(session()->has('gagal')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('gagal')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<div class="mt-5">
    <?php if(session('resent')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <?php echo e(__('Tautan verifikasi baru telah dikirim ke alamat email Anda.')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <h4>Data Diri</h4>
    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">Nomor Identitas</th>
                <td>: <?php echo e(auth()->user()->uuid); ?></td>
            </tr>
            <tr>
                <th scope="row">Username</th>
                <td>: <?php echo e(auth()->user()->username); ?></td>
            </tr>
            <tr>
                <th scope="row" class="col-4">Nama</th>
                <td class="col-8">: <?php echo e(auth()->user()->nm_lengkap); ?></td>
            </tr>
            <tr>
                <th scope="row">Alamat</th>
                <td>: <?php echo e(auth()->user()->alamat); ?></td>

            </tr>
            <tr>
                <th scope="row">Whatsapp</th>
                <td>: <?php echo e(auth()->user()->no_hp); ?></td>
            </tr>
            <tr>
                <th scope="row">Email</th>
                <td>: <?php echo e(auth()->user()->email); ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php if(auth()->user()->email_verified_at == null): ?>
<p style="text-align: justify;">Sebelum melanjutkan, harap periksa email anda untuk tautan verifikasi.</p>
<p style="text-align: justify;">Jika anda tidak menerima email tersebut klik <b class="text-danger">Kirim Ulang Verifikasi Email.</b></p>
<p style="text-align: justify;">Jika email salah klik <b class="text-danger">Ubah.</b></p>
<?php endif; ?>
<div class="justify-content-between d-sm-flex flex-row ">
    <?php if(auth()->user()->email_verified_at == null): ?>
    <a class="text-decoration-none" href="/email/change">
        <button type="button" class="btn btn-outline-warning w-100 my-1">Ubah Email</button>
    </a>

    <form class="d-inline" method="POST" action="<?php echo e(route('verification.send.otp')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-success w-100 my-1">Verifikasi Email</button>
    </form>
    <?php else: ?>
    <a class="text-decoration-none" href="/dashboard/profil/ubah">
        <button type="button" class="btn btn-outline-warning w-100 my-1">Ubah</button>
    </a>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/profil.blade.php ENDPATH**/ ?>