

<?php $__env->startSection('container-user'); ?>
<?php
$today = \Carbon\Carbon::now()->format('Y-m-d');
?>

<?php if(session()->has('gagal')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('gagal')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="container-fluid">
    <h2 class="text-center my-4">Form Permohonan</h2>
    <!-- Map -->
    <div id="mapkontak"></div>
    <div class="desc" id="desc"></div>
    <div class="card mt-3 mb-1 d-block d-lg-none">
        <div class="card-body">
            <h5>Filter</h5>
            <button class="btn btn-primary" id="filterJln">Jalan</button>
            <button class="btn btn-success" id="filterRth">RTH</button>
            <button class="btn btn-danger" id="resetFilters">Reset</button>
        </div>
        <div class="card-body" id="info">Klik untuk menampilkan fitur</div>
    </div>
    <?php if($data->status == 0 || $data->status == 1): ?>
    <button id="addMarkerButton" class="btn btn-success mt-1">Klik untuk mendapatkan koordinat</button>
    <?php endif; ?>

    <form action="/dashboard/<?php echo e($data->slug); ?>/edit" method="POST" enctype="multipart/form-data" id="form">

        <?php echo csrf_field(); ?>
        <div class="form-floating mt-3">
            <input name="uuid" disabled type="text" class="form-control" id="uuid" placeholder="uuid" value="<?php echo e(auth()->user()->uuid); ?>">
            <label for="uuid">Nomor Identitas</label>
        </div>
        <?php $__errorArgs = ['uuid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-floating mt-3">
            <input <?php echo e($data->status === "4.3" ? 'disabled' : ''); ?> type="text" class="form-control" id="nik" placeholder="nik" value="<?php echo e($data->nik); ?>" minlength="16" maxlength="16" pattern="\d{16}" title="Harap masukkan tepat 16 digit angka">
            <label for="nik">NIK</label>
        </div>
        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="lat" placeholder="lat" value="<?php echo e($data->lat); ?>">
            <label for="lat">lat</label>
        </div>
        <input name="lat" type="hidden" id="latvalue" placeholder="lat" value="<?php echo e($data->lat); ?>">
        <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="long" placeholder="long" value="<?php echo e($data->long); ?>">
            <label for="long">long</label>
        </div>
        <input name="long" type="hidden" id="longvalue" placeholder="long" value="<?php echo e($data->long); ?>">
        <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="loc_phnpt" placeholder="loc_phnpt" value="<?php echo e($data->loc_phnpt); ?>">
            <label for="loc_phnpt">Lokasi pada peta</label>
        </div>
        <input name="loc_phnpt" type="hidden" class="form-control" id="loc_phnptvalue" placeholder="loc_phnpt" value="<?php echo e($data->loc_phnpt); ?>">
        <?php $__errorArgs = ['loc_phnpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if($data->status == 0 || $data->status == 1): ?>
        <div class="form-floating mt-3">
            <input name="loc_phntts" type="text" class="form-control" id="loc_phntts" placeholder="loc_phntts" value="<?php echo e($data->loc_phntts); ?>">
            <label for="loc_phntts">Lokasi tertulis</label>
        </div>
        <?php $__errorArgs = ['loc_phntts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="overflow-auto mt-3" style="max-height: 400px;">
            <!-- Foto RTH -->
            <div class="fotorth card-body">
                <h5>
                    Foto RTH : <span class="text-secondary fs-6">Klik Foto untuk mengganti</span>
                </h5>
                <?php $__errorArgs = ['fotos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    foto rth : <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="fotoContainer row gap-3 mx-3 justify-content-between" id="fotoContainer">
                    <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $fileExtension = pathinfo(asset('/' . $foto->ftphn), PATHINFO_EXTENSION);
                    ?>
                    <div class="card col-12 col-md-4 col-lg-3">
                        <div class="" style="height: 150px; overflow:hidden;">
                            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
                            <img src="<?php echo e(asset('/' . $foto->ftphn)); ?>" class="img-thumbnail foto" alt="fotorth" style="cursor: pointer;" data-index="<?php echo e($key); ?>">
                            <?php elseif($fileExtension === 'pdf'): ?>
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $foto->ftphn)); ?>" type="button" data-index="<?php echo e($key); ?>><i class=" bi bi-file-earmark-pdf-fill"></i>Lihat Pdf</button>
                            <?php endif; ?>
                            <input accept="image/*,application/pdf" name="fotos[]" type="file" class="selectedPhotos image-field" style="display: none;" data-index="<?php echo e($key); ?>">
                        </div>
                        <div class="card-text my-2">
                            <button class="btn btn-danger btn-delete btn-delete1 w-100" type="button" data-index-del="<?php echo e($key); ?>">Hapus</button>
                            <input type="hidden" name="deleted_photos[]" class="deletedPhotoIndex" value="<?php echo e($key); ?>">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h5 class="mt-3">Tambah foto rth</h5>
                <?php $__errorArgs = ['addfotos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    addfotos : <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input accept="image/*,application/pdf" type="file" id="addfotos" name="addfotos[]" class="form-control my-2 image-field" multiple>
                <p class="fw-light">*jpeg, png, pdf 2mb</p>

            </div>

            <!-- Lampiran Rekomendasi Kapanewon -->
            <div class="fotorth card-body">
                <h5>
                    Lampiran Rekomendasi Kapanewon : <span class="text-secondary fs-6">Klik Foto untuk mengganti</span>
                </h5>
                <?php $__errorArgs = ['lmrecs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    foto rth : <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="fotoContainer row gap-3 mx-3 justify-content-between" id="fotoContainer1">
                    <?php $__currentLoopData = $lmrecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $lmrec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $fileExtension = pathinfo(asset('/' . $lmrec->lmrec), PATHINFO_EXTENSION);
                    ?>
                    <div class="card col-12 col-md-4 col-lg-3">
                        <div class="" style="height: 150px; overflow:hidden;">
                            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
                            <img src="<?php echo e(asset('/' . $lmrec->lmrec)); ?>" class="img-thumbnail lmrec" alt="lmrec" style="cursor: pointer;" data-index1="<?php echo e($key1); ?>">
                            <?php elseif($fileExtension === 'pdf'): ?>
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $lmrec->lmrec)); ?>" type="button" data-index1="<?php echo e($key1); ?>"><i class="bi bi-file-earmark-pdf-fill"></i>Lihat Pdf</button>
                            <?php endif; ?>
                            <input name="lmrecs[]" type="file" class="selectedlmrecs image-field" style="display: none;" data-index1="<?php echo e($key1); ?>">
                        </div>
                        <div class="card-text my-2">
                            <button class="btn btn-danger btn-delete btn-delete2 w-100" type="button" data-index-del1="<?php echo e($key1); ?>">Hapus</button>
                            <input type="hidden" name="deleted_lmrecs[]" class="deletedlmrecsIndex" value="<?php echo e($key1); ?>">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h5 class="mt-3">Tambah Lampiran Rekomendasi Kapanewon</h5>
                <?php $__errorArgs = ['addlmrec.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    addfotos : <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="file" id="addlmrec" name="addlmrec[]" class="form-control my-2 image-field" multiple>
                <p class="fw-light">*jpeg, png, pdf 2mb</p>

            </div>

            <!-- Foto KTP -->
            <div class="card-body">
                <h5 class="mt-3">
                    Foto KTP : <span class="text-secondary fs-6">Klik Foto untuk mengganti. </span>
                </h5>
                <p class="fw-light">*jpeg, png, pdf 2mb</p>
                <?php $__errorArgs = ['ftktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    fotoktp : <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php
                $fileExtension = pathinfo(asset('/' . $data->ftktp), PATHINFO_EXTENSION);
                ?>
                <input type="file" id="selectedPhotoktp" class="image-field" name="ftktp" value="<?php echo e($fotoktp); ?>" style="display: none;">
                <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
                <img id="fotoktp" style="cursor: pointer; display: block;" src="<?php echo e(asset('/'.$fotoktp)); ?>" class="img-thumbnail d-inline-flex" alt="fotoktp" width="30%">
                <div id="pdfContainer" class="card col-12 col-md-4 col-lg-3" style="display: none;">
                    <div class="" style="height: 150px; overflow:hidden;">
                        <button id="showpdf" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $data->ftktp)); ?>" type="button"><i class="bi bi-file-earmark-pdf-fill"></i>Lihat Pdf</button>
                        <button type="button" id="editPdfBtn" class="btn btn-warning w-100 mt-2">Edit</button>
                    </div>
                </div>
                <?php elseif($fileExtension === 'pdf'): ?>
                <div id="pdfContainer" class="card col-12 col-md-4 col-lg-3">
                    <div class="" style="height: 150px; overflow:hidden;">
                        <button id="showpdf" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $data->ftktp)); ?>" type="button"><i class="bi bi-file-earmark-pdf-fill"></i>Lihat Pdf</button>
                        <button type="button" id="editPdfBtn" class="btn btn-warning w-100 mt-2">Edit</button>
                    </div>
                </div>
                <img id="fotoktp" style="display: none; cursor: pointer;" class="img-thumbnail" alt="fotoktp" width="30%" />
                <?php endif; ?>
            </div>

        </div>

        <div class="form-floating mt-3">
            <textarea name="alasan" class="form-control" placeholder="Alasan Perizinan" id="alasan" style="height: 100px"><?php echo e($data->alasan); ?></textarea>
            <label for="alasan">Keterangan</label>
        </div>
        <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php elseif($data->status == 4.3): ?>
        <div class="form-floating mt-3">
            <input type="date" class="form-control" max="<?php echo e($today); ?>" min="<?php echo e($data->created_at->format('Y-m-d')); ?>" id="tgl_pelaksanaan" placeholder="yyyy-mm-dd" name="tgl_pelaksanaan" value="<?php echo e(old('tgl_pelaksanaan')); ?>">
            <label for="tgl_pelaksanaan">Pelaksanaan</label>
        </div>

        <?php $__errorArgs = ['tgl_pelaksanaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="mt-3">
            <label for="pelaksanaan" class="form-label">Foto Pelaksanaan</label>
            <input name="pelaksanaan[]" class="form-control image-field" type="file" id="pelaksanaan" multiple accept="image/*,application/pdf">
        </div>
        <div id="preview-images" class="mt-3"></div>

        <?php if($errors->has('pelaksanaan')): ?>
        <?php $__currentLoopData = $errors->get('pelaksanaan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endif; ?>
        <input type="text" hidden name="stt" id="stt">
        <button type="submit" class="btn btn-success my-3">Submit</button>
    </form>
    <div class="mb-2">
        <a href="<?php echo e($backUrl); ?>">
            <button type="button" class="btn btn-outline-success">Kembali</button>
        </a>
    </div>

</div>
</div>
<!-- Modal -->
<div class="modal fade" id="pdfModal" tabindex="-1" aria-labelledby="pdfModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pdfModalLabel">PDF Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <embed id="pdfEmbed" src="" type="application/pdf" width="100%" height="400px" />
            </div>
        </div>
    </div>
</div>
<?php if(auth()->user()): ?>
<div id="admin-status" data-is-admin="<?php echo e(auth()->user()->admin); ?>"></div>
<?php else: ?>
<div id="admin-status" data-is-admin=""></div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/browser-image-compression@1.0.15/dist/browser-image-compression.min.js"></script>
<script src="/js/geojson.js"></script>
<script src="/js/changefotos.js"></script>
<script src="/js/form.js"></script>
<?php if($data->status == 4.3): ?>
<script src="/js/form3.js"></script>
<?php else: ?>
<script src="/js/form2.js"></script>
<?php endif; ?>

<script src="/js/compressimg.js"></script>
<script src="/js/showimg.js"></script>
<?php if($data->status != 4.3): ?>
<script src="/js/pdfreader.js"></script>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/ubahklhn.blade.php ENDPATH**/ ?>