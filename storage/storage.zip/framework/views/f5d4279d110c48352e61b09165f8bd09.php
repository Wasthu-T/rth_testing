<?php if(auth()->user()->email_verified_at == null): ?>
<li class="list-item">
    <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3 <?php echo e(request() -> path() === "email/verify" ? 'active' : ''); ?> <?php echo e(request() -> path() === "dashboard/profil/ubah" ? 'active' : ''); ?>" href="/dashboard/profil">
        Verifikasi
    </a>
</li>
<?php else: ?>
<li class="list-item">
    <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3 <?php echo e(request() -> path() === "dashboard/profil" ? 'active' : ''); ?> <?php echo e(request() -> path() === "dashboard/profil/ubah" ? 'active' : ''); ?>" href="/dashboard/profil">
        Profil
    </a>
</li>

<li class="list-item">
    <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3 <?php echo e(request() -> path() === "dashboard" ? 'active' : ''); ?>" href="/dashboard">
        Daftar Permohonan
    </a>
</li>

<li class="list-item">
    <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3 <?php echo e(request() -> path() === "dashboard/permohonan" ? 'active' : ''); ?>" aria-current="page" href="/dashboard/permohonan">
        Permohonan
    </a>
</li>
<li class="nav-item <?php echo e(request()->is('dashboard/bantuan*') ? 'active' : ''); ?>">
    <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3" href="/dashboard/bantuan/membuatlaporan">
        Bantuan
    </a>
    <?php if(request()->is('dashboard/bantuan*')): ?>
    <ul class="flex-column ms-3" style="list-style-type: none;">
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->path() === 'dashboard/bantuan/membuatlaporan' ? 'active' : ''); ?>" href="/dashboard/bantuan/membuatlaporan">
                Membuat Laporan
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->path() === 'dashboard/bantuan/memperbaikikesalahanlaporan' ? 'active' : ''); ?>" href="/dashboard/bantuan/memperbaikikesalahanlaporan">
                Memperbaiki Kesalahan Laporan
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->path() === 'dashboard/bantuan/pelaksanaanmasyarakat' ? 'active' : ''); ?>" href="/dashboard/bantuan/pelaksanaanmasyarakat">
                Pelaksanaan Masyarakat
            </a>
        </li>
    </ul>
    <?php endif; ?>
</li>
<?php endif; ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/partials/user.blade.php ENDPATH**/ ?>