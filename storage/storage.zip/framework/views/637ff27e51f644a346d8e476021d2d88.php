<header class="navbar sticky-top bg-success flex-md-nowrap p-0 shadow ">
    <?php if(auth()->user()->admin == 0): ?>
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6 text-white" href="#"><?php echo e(auth()->user()->username); ?></a>
    <?php else: ?>
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6 text-white" href="#"><?php echo e(auth()->user()->nm_lengkap); ?></a>
    <?php endif; ?>

    <ul class="navbar-nav flex-row d-md-none">
        <li class="nav-item text-nowrap">
            <button class="nav-link px-3 text-white" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="bi bi-list"></i>
            </button>
        </li>
    </ul>
</header>


<div class="container-fluid ">
    <div class="row ">
        <div class="nav nav-underline text-white border-right col-md-3 col-lg-2 bg-success sidebar-bg">
            <div class=" offcanvas-md offcanvas-end bg-success " tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="sidebarMenuLabel"><?php echo e(auth()->user()->nm_dpn); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body text-white d-md-flex flex-column p-0 mt-5 ">
                    <ul class="list-group">
                        <?php if(auth()->user()->admin == 0): ?>
                        <?php echo $__env->make('users.partials.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                        <?php echo $__env->make('users.partials.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </ul>



                    <hr class="my-3">

                    <ul class="list-group flex-column mb-auto">
                        <li class="list-item">
                            <a class="nav-link d-flex align-items-center gap-2 mx-3 px-3 w-75" aria-current="page" href="/beranda">
                                Beranda
                            </a>
                        </li>
                        <li class="list-item">
                            <form action="/keluar" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="nav-link d-flex align-items-center gap-2 mx-3 px-3 w-75">
                                    Keluar
                                </button>
                            </form>
                        </li>
                        </li>
                    </ul>
                </div>
            </div>
        </div><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/partials/navbar.blade.php ENDPATH**/ ?>