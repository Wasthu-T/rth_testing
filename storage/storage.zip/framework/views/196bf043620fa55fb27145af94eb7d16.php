

<?php $__env->startSection('container'); ?>
<div class="modal modal-sheet position-static d-block " tabindex="-1" role="dialog" id="modalSignin">

  <?php if(session()->has('status')): ?>
  <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('status')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php endif; ?>
  <?php if(session()->has('loginError')): ?>
  <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('loginError')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php endif; ?>

  <div class="modal-dialog" role="document">
    <div class="modal-content rounded-4 shadow">
      <div class="border-bottom-0 m-3">
        <h1 class="fw-bold mb-0 fs-2 text-center"><img src="/img/logo/simpel-rth-light-removebg-preview (1).png" alt="rth" width="50px" height="auto"> Masuk</h1>
      </div>

      <div class="container row row-cols-1 row-cols-lg-2 text-center mx-auto my-3 gap-lg-0 gap-2">
        <div class="col">
          <a class="btn btn-outline-success w-100 <?php echo e(request() -> segment(1) === "masuk" ? 'active' : ''); ?>" role="button" href="/masuk">Masuk</a>
        </div>
        <div class="col">
          <a class="btn btn-outline-success w-100 <?php echo e(request() -> segment(1) === "daftar" ? 'active' : ''); ?>" role="button" href="/daftar">Daftar</a>
        </div>
      </div>

      <div class="modal-body pt-0">

        <form action="/masuk" method="POST">
          <?php echo csrf_field(); ?>

          <div class="form-floating mb-3">
            <input name="username" type="text" class="form-control rounded-3 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="xxxxxxxxxxxxxxxx" value="<?php echo e(old('username')); ?>" autofocus required>
            <label for="username">Username / No Hp / Email</label>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
              <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-floating">
            <input name="password" type="password" class="form-control rounded-3" id="password" placeholder="Password" required>
            <label for="password">Password</label>
            <span id="togglePassword" class="position-absolute" style="right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
              <i class="bi bi-eye"></i>
            </span>
            <?php if($errors->has('g-recaptcha-response')): ?>
            <span class="help-block text-danger">
              <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
          <div class="mb-3 justify-content-end d-flex mx-3">
            <a href="<?php echo e(route('password.request')); ?>" class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover" style="font-size: .9em;">Lupa Password?</a>
          </div>
          <div class="form-floating mb-3">
            <?php echo NoCaptcha::renderJs(); ?>

            <?php echo NoCaptcha::display(); ?>

          </div>
          <button class="w-100 mb-2 btn btn-lg rounded-3 btn-success" type="submit"><i class="bi bi-box-arrow-in-right"></i>Masuk</button>

        </form>

      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('form.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/form/login.blade.php ENDPATH**/ ?>