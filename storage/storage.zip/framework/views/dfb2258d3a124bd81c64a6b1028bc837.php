

<?php $__env->startSection('container-user'); ?>

<div class="container-fluid">
    <h2 class="text-center my-4">Form Permohonan</h2>
    <!-- Map -->
    <div id="mapkontak"></div>
    <div class="desc" id="desc"></div>

    <div class="card mt-3 mb-1 d-block d-lg-none">
        <div class="card-body">
            <h5>Filter</h5>
            <button class="btn btn-primary" id="filterJln">Jalan</button>
            <button class="btn btn-success" id="filterRth">RTH</button>
            <button class="btn btn-danger" id="resetFilters">Reset</button>
        </div>
        <div class="card-body" id="info">Klik untuk menampilkan fitur</div>
    </div>
    <button id="addMarkerButton" class="btn btn-success mt-1">Klik untuk mendapatkan koordinat</button>

    <form action="/dashboard/permohonan" method="POST" enctype="multipart/form-data" id="form">
        <?php echo csrf_field(); ?>

        <div class="form-floating mt-3">
            <input name="uuid" disabled type="text" class="form-control" id="uuid" placeholder="uuid" value="<?php echo e(auth()->user()->uuid); ?>">
            <label for="uuid">Nomor Permohonan</label>
        </div>
        <?php $__errorArgs = ['uuid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-floating mt-3">
            <input name="nik" onkeypress="return /[0-9]/i.test(event.key)" type="text" class="form-control" id="nik" placeholder="nik" value="<?php echo e(auth()->user()->nik); ?>" minlength="16" maxlength="16" pattern="\d{16}" title="Harap masukkan tepat 16 digit angka">
            <label for="nik">NIK</label>
        </div>
        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="lat" placeholder="lat" value="<?php echo e(old('lat')); ?>">
            <label for="lat">Lintang</label>
        </div>
        <input name="lat" type="hidden" id="latvalue" placeholder="lat" value="<?php echo e(old('lat')); ?>">
        <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="long" placeholder="long" value="<?php echo e(old('long')); ?>">
            <label for="long">Bujur</label>
        </div>
        <input name="long" type="hidden" id="longvalue" placeholder="long" value="<?php echo e(old('long')); ?>">
        <?php $__errorArgs = ['long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-floating mt-3">
            <input disabled type="text" class="form-control" id="loc_phnpt" placeholder="loc_phnpt" value="<?php echo e(old('loc_phnpt')); ?>">
            <label for="loc_phnpt">Lokasi pada peta</label>
        </div>
        <input name="loc_phnpt" type="hidden" class="form-control" id="loc_phnptvalue" placeholder="loc_phnpt" value="<?php echo e(old('loc_phnpt')); ?>">
        <?php $__errorArgs = ['loc_phnpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-content">

            <div class="form-floating mt-3">
                <input disabled name="loc_phntts" type="text" class="check-input form-control" id="loc_phntts" placeholder="loc_phntts" value="<?php echo e(old('loc_phntts')); ?>">
                <label for="loc_phntts">Lokasi tertulis</label>
            </div>
            <?php $__errorArgs = ['loc_phntts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-floating mt-3">
                <textarea disabled name="alasan" class="check-input form-control" placeholder="Menghalangi rambu lalu lintas" id="alasan" style="height: 100px"></textarea>
                <label for="alasan">Keterangan</label>
            </div>
            <p class="fs5 text-secondary">Contoh : Menghalangi rambu lalu lintas/ Pohon tumbang/ Pemangkasan</p>

            <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="mt-3">
                <label for="ftphn" class="form-label">Foto Pohon</label>
                <input disabled name="ftphn[]" class="check-input form-control image-field" type="file" id="ftphn" accept="image/*,application/pdf" multiple>
                <p class="fw-light">*jpeg, png, pdf</p>
            </div>
            <?php if($errors->has('ftphn')): ?>
            <?php $__currentLoopData = $errors->get('ftphn'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php $__errorArgs = ['ftphn.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mt-3">
                <label for="lmrec" class="form-label">Lampiran Rekomendasi Kapanewon</label>
                <input disabled name="lmrec[]" class="check-input form-control image-field" type="file" id="lmrec" accept="image/*,application/pdf" multiple>
                <p class="fw-light">*jpeg, png, pdf</p>
            </div>
            <?php if($errors->has('lmrec')): ?>
            <?php $__currentLoopData = $errors->get('lmrec'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php $__errorArgs = ['lmrec.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mt-3">
                <label for="ftktp" class="form-label">Foto FC KTP</label>
                <input disabled name="ftktp" class="check-input form-control image-field" type="file" accept="image/*,application/pdf" id="ftktp">
                <p class="fw-light">*jpeg, png, pdf</p>
            </div>
            <?php $__errorArgs = ['ftktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="text" hidden name="stt" id="stt" value="">
        <input type="text" hidden name="jln" id="jln" value="">
        <?php if($errors->has('g-recaptcha-response')): ?>
        <span class="help-block text-danger">
            <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
        </span>
        <?php endif; ?>
        <div class="form-floating mb-3">
            <?php echo NoCaptcha::renderJs(); ?>

            <?php echo NoCaptcha::display(); ?>

        </div>
        <button type="submit" id="Submit" class="btn btn-success my-3">Submit</button>
    </form>

</div>
</div>
</div>
<?php if(auth()->user()): ?>
<div id="admin-status" data-is-admin="<?php echo e(auth()->user()->admin); ?>"></div>
<?php else: ?>
<div id="admin-status" data-is-admin=""></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/browser-image-compression@1.0.15/dist/browser-image-compression.min.js"></script>
<script src="/js/geojson.js"></script>
<script src="/js/form.js"></script>
<script src="/js/form2.js"></script>
<script src="/js/compressimg.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/permohonan.blade.php ENDPATH**/ ?>