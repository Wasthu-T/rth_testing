

<?php $__env->startSection('container-user'); ?>

<?php if(request()->is('dashboard/bantuan/membuatlaporan')): ?>
<?php echo $__env->make('users.user.bantuan1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php elseif(request()->is('dashboard/bantuan/memperbaikikesalahanlaporan')): ?>
<?php echo $__env->make('users.user.bantuan2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php elseif(request()->is('dashboard/bantuan/pelaksanaanmasyarakat')): ?>
<?php echo $__env->make('users.user.bantuan3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/bantuan.blade.php ENDPATH**/ ?>