

<?php $__env->startSection('container-user'); ?>

<?php if(request()->is('dashboard/admin/bantuan/filter')): ?>
<?php echo $__env->make('users.admin.bantuan.rth1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php elseif(request()->is('dashboard/admin/bantuan/tampilanrekapitulasi')): ?>
<?php echo $__env->make('users.admin.bantuan.rth2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php elseif(request()->is('dashboard/admin/bantuan/hapuspermohonan')): ?>
<?php echo $__env->make('users.admin.bantuan.rth5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php elseif(request()->is('dashboard/admin/bantuan/prosespermohonan')): ?>
<?php if(auth()->user()->akses_lvl == 2): ?>
<?php echo $__env->make('users.admin.bantuan.rth3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('users.admin.bantuan.rth4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php endif; ?>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/bantuan.blade.php ENDPATH**/ ?>