

<?php $__env->startSection('container-user'); ?>

<?php if(session()->has('status')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('status')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('gagal')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('gagal')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<div class="card my-3 mx-3 text-center">
    <h5 class="card-header">Verifikasi OTP</h5>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('verification.verify.otp')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="floatingInput" placeholder="111111" maxlength="6" id="otp" name="otp" onkeypress="return /[0-9]/i.test(event.key)" required>
                <label for="floatingInput">Kode OTP:</label>
            </div>
            <button type="submit" class="btn btn-outline-success w-100">Verifikasi</button>
        </form>

        <form action="/email/verify" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-secondary my-1 w-100">
                Kirim ulang kode otp
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/verify-otp.blade.php ENDPATH**/ ?>