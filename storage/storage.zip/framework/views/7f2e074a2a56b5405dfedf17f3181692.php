<!DOCTYPE html>
<html>
<head>
    <title>Verifikasi Email</title>
</head>
<body>
    <p><b>Jangan share kode otp anda ke orang asing.</b></p>
    <p>Kode Otp Anda : <?php echo e($otp); ?></p>
</body>
</html>
<?php /**PATH D:\App\sistem-informasi-web\resources\views/emails/verify-otp.blade.php ENDPATH**/ ?>