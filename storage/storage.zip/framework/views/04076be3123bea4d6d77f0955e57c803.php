<table class="table">
    <thead>
        <tr>
            <th scope="col">Nik</th>
            <th scope="col">Alamat</th>
            <th scope="col">Lintang</th>
            <th scope="col">Bujur</th>
            <th scope="col">Alasan</th>
            <th scope="col">Tgl Buat</th>
            <th scope="col">Terakhir Ubah</th>
            <th scope="col">Status</th>
            <th scope="col">Tindakan</th>
        </tr>
    </thead>
    <tbody>
        <div id="searchResults">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->nik); ?></td>
                <td><?php echo e($data->loc_phntts); ?></td>
                <td><?php echo e(number_format($data->lat,4)); ?></td>
                <td><?php echo e(number_format($data->long,4)); ?></td>
                <td class="text-truncate" style="max-width: 150px;"><?php echo e($data->alasan); ?></td>
                <td class="text-nowrap"><?php echo e($data->created_at->format('d/m/Y')); ?></td>
                <td class="text-nowrap"><?php echo e($data->updated_at->format('d/m/Y')); ?></td>
                <?php if($data->status == 0): ?>
                <td class="text-danger">Data kurang lengkap/salah</td>
                <?php elseif($data->status == 1): ?>
                <td class="text-danger">Menunggu diproses</td>
                <?php elseif($data->status == 2): ?>
                <td class="text-primary">Sedang ditinjau</td>
                <?php elseif($data->status == 3): ?>
                <td class="text-primary">Menunggu surat rekomendasi</td>
                <?php elseif($data->status == 4.1 || $data->status == 4.2 || $data->status == 4.3): ?>
                <td class="text-primary">Sedang dilaksanakan</td>
                <?php elseif($data->status == 5): ?>
                <td class="text-success">Selesai</td>
                <?php elseif($data->status == 6): ?>
                <td class="text-primary">Status jalan <?php echo e($data->istansi); ?></td>
                <?php else: ?>
                <td class="text-danger">Error silahkan menghubungi admin</td>
                <?php endif; ?>
                <td class="justify-content-evenly">
                    <?php if(Request::path() == "dashboard/admin/arsip"): ?>
                    <span class="mx-3 my-2">
                        <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#confirmPulihkanModal" data-slug="<?php echo e($data->slug); ?>">
                            <i class="bi bi-box-arrow-up-right"></i>Pulihkan
                        </button>
                    </span>
                    <?php else: ?>
                    <a href="/dashboard/admin/<?php echo e($data->slug); ?>" class="mx-3 my-2">
                        <button type="button" class="btn btn-outline-success"><i class="bi bi-box-arrow-in-down-left"></i>Tinjau</button>
                    </a>

                    <?php if((auth()->user()->akses_lvl == "2") && ($data->status == 0 || $data->status == 1) ): ?>
                    <span class="mx-3 my-2">
                        <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal" data-slug="<?php echo e($data->slug); ?>">
                            <i class="bi bi-trash"></i> Hapus
                        </button>
                    </span>
                    <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </tbody>
</table>

<?php if(Request::path() == "dashboard/admin"): ?>
<!-- Modal -->
<div class="modal fade mt-5" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Penghapusan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus data dengan kode <span id="deleteSlug"></span> ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(Request::path() == "dashboard/admin/arsip"): ?>
<!-- Modal Konfirmasi Pemulihan -->
<div class="modal fade mt-5" id="confirmPulihkanModal" tabindex="-1" aria-labelledby="confirmPulihkanModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmPulihkanModalLabel">Konfirmasi Pemulihan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin memulihkan data dengan kode <span id="pulihkanSlug"></span> ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form id="pulihkanForm" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-success">Pulihkan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($datas->count() === 0): ?>
<h5 class="text-danger">Data tidak ditemukan</h5>
<?php endif; ?>
<?php echo $datas->links(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var confirmDeleteModal = document.getElementById('confirmDeleteModal');
        confirmDeleteModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget; // Tombol yang memicu modal
            var slug = button.getAttribute('data-slug'); // Ambil slug dari tombol
            var deleteForm = document.getElementById('deleteForm');
            var deleteSlug = document.getElementById('deleteSlug'); // Elemen untuk menampilkan slug
            deleteForm.action = "/dashboard/admin/arsip/" + slug;
            deleteSlug.textContent = slug; // Set slug ke elemen
        });

        var confirmPulihkanModal = document.getElementById('confirmPulihkanModal');
        confirmPulihkanModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget; // Tombol yang memicu modal
            var slug = button.getAttribute('data-slug'); // Ambil slug dari tombol
            var pulihkanForm = document.getElementById('pulihkanForm');
            var pulihkanSlug = document.getElementById('pulihkanSlug'); // Elemen untuk menampilkan slug
            pulihkanForm.action = "/dashboard/admin/pulihkan/" + slug;
            pulihkanSlug.textContent = slug; // Set slug ke elemen
        });
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/tabledatastatus.blade.php ENDPATH**/ ?>