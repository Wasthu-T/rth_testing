

<?php $__env->startSection('container-user'); ?>
<div class="card w-100 mb-4">

    <div class="overflow-auto mt-3" style="max-height: 400px;">
        <!-- Foto Rth -->
        <?php if($fotos && count($fotos) > 0): ?>
        <h5 class="card-title">Foto RTH : </h5>
        <div class="row">
            <?php
            $index = 1;
            ?>

            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $foto->ftphn), PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <img src="<?php echo e(asset('/' . $foto->ftphn)); ?>" class="img-thumbnail" alt="fotorth" width="100%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $foto->ftphn)); ?>" class="btn btn-success w-100">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf <?php echo e($index); ?>

                </button>
            </div>

            <?php
            $index ++;
            ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Lampiran Rekomendasi Kapanewon -->
        <?php if($lms && count($lms) > 0): ?>
        <h5 class="card-title">Lampiran Rekomendasi Kapanewon : </h5>
        <div class="row">
            <?php
            $index = 1;
            ?>
            <?php $__currentLoopData = $lms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lmrec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $lmrec), PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <img src="<?php echo e(asset('/' . $lmrec)); ?>" class="img-thumbnail" alt="lmrec" width="100%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $lmrec)); ?>" class="btn btn-success w-100">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf <?php echo e($index); ?>

                </button>
            </div>
            <?php
            $index ++;
            ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Foto KTP -->
        <div class="card-body">
            <?php if($fotoktp != null): ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $fotoktp), PATHINFO_EXTENSION);
            ?>
            <h5 class="card-title">Foto KTP : </h5>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="mb-3">
                <img src="<?php echo e(asset('/' . $fotoktp)); ?>" class="img-thumbnail" alt="fotoktp" width="50%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $fotoktp)); ?>" class="btn btn-success">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf KTP
                </button>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Foto Survei -->
        <?php if($surveis && count($surveis) > 0): ?>
        <?php
        $index = 1;
        ?>
        <h5 class="card-title">Foto Survei : </h5>
        <div class="row">
            <?php $__currentLoopData = $surveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survei): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $survei), PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <img src="<?php echo e(asset('/' . $survei)); ?>" class="img-thumbnail" alt="survei" width="100%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $survei)); ?>" class="btn btn-success w-100">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf <?php echo e($index); ?>

                </button>
            </div>
            <?php
            $index ++;
            ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Rekomendasi -->
        <?php if($suratrth && count($suratrth) > 0): ?>
        <?php
        $index = 1;
        ?>
        <h5 class="card-title">Rekomendasi : </h5>
        <div class="row">
            <?php $__currentLoopData = $suratrth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $surat), PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <img src="<?php echo e(asset('/' . $surat)); ?>" class="img-thumbnail" id="surat" alt="surat" width="100%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $surat)); ?>" class="btn btn-success w-100">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf <?php echo e($index); ?>

                </button>
            </div>
            <?php
            $index ++;
            ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Foto Pelaksana -->
        <?php if($pelaksanas && count($pelaksanas) > 0): ?>
        <?php
        $index = 1;
        ?>
        <h5 class="card-title">Foto Pelaksana : </h5>
        <div class="row">
            <?php $__currentLoopData = $pelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelaksana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fileExtension = pathinfo(asset('/' . $pelaksana), PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <img src="<?php echo e(asset('/' . $pelaksana)); ?>" class="img-thumbnail" alt="pelaksana" width="100%">
            </div>
            <?php elseif($fileExtension === 'pdf'): ?>
            <div class="col-12 col-md-4 col-lg-3 mb-3">
                <button data-bs-toggle="modal" data-bs-target="#pdfModal" data-pdf="<?php echo e(asset('/' . $pelaksana)); ?>" class="btn btn-success w-100">
                    <i class="bi bi-file-earmark-pdf-fill"></i> Lihat Pdf <?php echo e($index); ?>

                </button>
            </div>
            <?php
            $index ++;
            ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Modal -->
    <div class="modal fade mt-5" id="pdfModal" tabindex="-1" aria-labelledby="pdfModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="pdfModalLabel">PDF Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <embed id="pdfEmbed" src="" type="application/pdf" width="100%" height="400px" />
                </div>
            </div>
        </div>
    </div>
    <?php if($data): ?>
    <div class="card-body">
        <h5 class="card-title">Kode : <?php echo e($data->slug); ?></h5>
        <div class="position-relative m-4">
            <div class="container mt-5">
                <?php
                $progressWidth = 0;
                $step1Color = 'btn-secondary';
                $step2Color = 'btn-secondary';
                $step3Color = 'btn-secondary';
                $step4Color = 'btn-secondary';
                $step5Color = 'btn-secondary';
                $step6Color = 'btn-secondary';
                $progresscolor = 'bg-danger';

                switch($data->status) {
                case 0:
                $progressWidth = 0;
                $step1Color = 'btn-danger';
                $progresscolor = 'bg-danger';
                break;
                case 1:
                $progressWidth = 20;
                $step1Color = 'btn-danger';
                $step2Color = 'btn-danger';
                $progresscolor = 'bg-danger';
                break;
                case 2:
                $progressWidth = 40;
                $step1Color = 'btn-primary';
                $step2Color = 'btn-primary';
                $step3Color = 'btn-primary';
                $progresscolor = 'bg-primary';
                break;
                case 3:
                $progressWidth = 60;
                $step1Color = 'btn-primary';
                $step2Color = 'btn-primary';
                $step3Color = 'btn-primary';
                $step4Color = 'btn-primary';
                $progresscolor = 'bg-primary';
                break;
                case 4.1:
                case 4.2:
                case 4.3:
                $progressWidth = 80;
                $step1Color = 'btn-primary';
                $step2Color = 'btn-primary';
                $step3Color = 'btn-primary';
                $step4Color = 'btn-primary';
                $step5Color = 'btn-primary';
                $progresscolor = 'bg-primary';
                break;
                case 5:
                $progressWidth = 100;
                $step1Color = 'btn-success';
                $step2Color = 'btn-success';
                $step3Color = 'btn-success';
                $step4Color = 'btn-success';
                $step5Color = 'btn-success';
                $step6Color = 'btn-success';
                $progresscolor = 'bg-success';
                break;
                case 6:
                $progressWidth = 100;
                $step1Color = 'btn-primary';
                $step2Color = 'btn-primary';
                $step3Color = 'btn-primary';
                $step4Color = 'btn-primary';
                $step5Color = 'btn-primary';
                $step6Color = 'btn-primary';
                $progresscolor = 'bg-primary';
                break;
                default:
                $progressWidth = 0;
                break;
                }
                ?>
                <div class="position-relative">
                    <div class="progress" role="progressbar" aria-label="Progress" aria-valuenow="<?php echo e($progressWidth); ?>" aria-valuemin="0" aria-valuemax="100" style="height: 1px;">
                        <div class="progress-bar <?php echo e($progresscolor); ?>" id="progress-bar" style="width: <?php echo e($progressWidth); ?>%;"></div>
                    </div>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Data kurang lengkap/salah" class="position-absolute top-0 start-0 translate-middle btn btn-sm rounded-pill <?php echo e($step1Color); ?>" style="width: 2rem; height:2rem;">1</button>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Menunggu diproses" class="position-absolute top-0 start-20 translate-middle btn btn-sm rounded-pill <?php echo e($step2Color); ?>" style="width: 2rem; height:2rem;">2</button>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Sedang diditinjau" class="position-absolute top-0 start-40 translate-middle btn btn-sm rounded-pill <?php echo e($step3Color); ?>" style="width: 2rem; height:2rem;">3</button>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Menunggu surat rekomendasi" class="position-absolute top-0 start-60 translate-middle btn btn-sm rounded-pill <?php echo e($step4Color); ?>" style="width: 2rem; height:2rem;">4</button>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Sedang dilaksanakan" class="position-absolute top-0 start-80 translate-middle btn btn-sm rounded-pill <?php echo e($step5Color); ?>" style="width: 2rem; height:2rem;">5</button>
                    <button type="button" data-bs-trigger="hover focus" data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Selesai" class="position-absolute top-0 start-100 translate-middle btn btn-sm rounded-pill <?php echo e($step6Color); ?>" style="width: 2rem; height:2rem;">6</button>
                </div>

            </div>
        </div>
        <?php if($data->status == 0): ?>
        <h5 class="text-danger">Data kurang lengkap/salah</h5>
        <?php elseif($data->status == 1): ?>
        <h5 class="text-danger">Menunggu diproses</h5>
        <?php elseif($data->status == 2): ?>
        <h5 class="text-primary">Sedang ditinjau</h5>
        <?php elseif($data->status == 3): ?>
        <h5 class="text-primary">Menunggu surat rekomendasi</h5>
        <?php elseif($data->status == 4.1 || $data->status == 4.2 || $data->status == 4.3): ?>
        <h5 class="text-primary">Sedang dilaksanakan</h5>
        <?php elseif($data->status == 5): ?>
        <h5 class="text-success">Selesai</h5>
        <?php elseif($data->status == 6): ?>
        <h5 class="text-primary">Status jalan <?php echo e($data->istansi); ?></h5>
        <p class="text-danger">Tidak dapat dilanjuti dikarenakan jalan <?php echo e($data->istansi); ?></p>
        <?php else: ?>
        <h5 class="text-danger">Error silahkan menghubungi admin</h5>
        <?php endif; ?>
        <?php if(session()->has('status')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <strong><?php echo e(session('status')); ?> </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session()->has('statusgagal')): ?>
        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
            <strong><?php echo e(session('statusgagal')); ?> </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session()->has('gagal')): ?>
        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
            <strong><?php echo e(session('gagal')); ?> </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <table class="table table-borderless">
            <tbody>
                <tr>
                    <td colspan="2">
                        <h5>Data pemohon :</h5>
                    </td>
                </tr>
                <?php if($data->note != null): ?>
                <tr>
                    <td class="text-danger">Kekurangan data :</td>
                    <td class="text-danger">: <?php echo e($data->note); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td>NIK</td>
                    <td>: <?php echo e($data->nik); ?></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td>: <?php echo e($datauser->nm_lengkap); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>: <?php echo e($datauser->email); ?></td>
                </tr>
                <tr>
                    <td>No Hp</td>
                    <td>: <?php echo e($datauser->no_hp); ?></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <h5>Data permohonan :</h5>
                    </td>
                </tr>
                <tr>
                    <td>Lintang</td>
                    <td>: <?php echo e($data->lat); ?></td>
                </tr>
                <tr>
                    <td>Bujur</td>
                    <td>: <?php echo e($data->long); ?></td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                    <td>: <?php echo e($data->alasan); ?></td>
                </tr>
                <tr>
                    <td>Lokasi</td>
                    <td>: <?php echo e($data->loc_phntts); ?></td>
                </tr>
                <?php if($data->status != 6): ?>
                <tr>
                    <td>Lokasi Peta RTH</td>
                    <td>: <?php echo e($data->loc_phnpt); ?></td>
                </tr>
                <tr>
                    <td>Hasil survei</td>
                    <td>: <?php echo e($data->survei); ?></td>
                </tr>
                <tr>
                    <td>Dibuat</td>
                    <td>: <?php echo e($data->created_at->format('d/m/Y H:i:s')); ?> WIB</td>
                </tr>
                <tr>
                    <td>Mulai survei</td>
                    <?php if($data->tgl_survei != null): ?>
                    <td>: <?php echo e(date('d/m/Y', strtotime($data->tgl_survei))); ?></td>
                    <?php else: ?>
                    <td>: </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Diupdate</td>
                    <td>: <?php echo e($data->updated_at->format('d/m/Y H:i:s')); ?> WIB</td>
                </tr>
                <tr>
                    <td>Pelaksana</td>
                    <td>: <?php echo e($data->istansi); ?></td>
                </tr>
                <tr>
                    <td>Pelaksanaan</td>
                    <?php if($data->tgl_pelaksanaan != null): ?>
                    <td>: <?php echo e(date('d/m/Y', strtotime($data->tgl_pelaksanaan))); ?></td>
                    <?php else: ?>
                    <td>: </td>
                    <?php endif; ?>
                </tr>
                <?php else: ?>
                <tr>
                    <td>Dibuat</td>
                    <td>: <?php echo e($data->created_at->format('d/m/Y H:i:s')); ?> WIB</td>
                </tr>
                <tr>
                    <td>Diupdate</td>
                    <td>: <?php echo e($data->updated_at->format('d/m/Y H:i:s')); ?> WIB</td>
                </tr>
                <?php endif; ?>

            </tbody>
        </table>


    </div>
    <?php else: ?>
    <div class="text-danger">
        Data tidak ditemukan
    </div>
    <?php endif; ?>

    <div class="justify-content-between d-sm-flex flex-row mb-3 mx-3">
        <div class="mb-2">
            <a href="<?php echo e($backUrl); ?>" class=" text-decoration-none">
                <button type="button" class="btn btn-outline-success w-100">Kembali</button>
            </a>
        </div>
        <div class="mb-2">
            <a class="text-decoration-none " href="https://www.google.com/maps?q=<?php echo e($data->lat); ?>,<?php echo e($data->long); ?>" target="_blank">
                <button type="button" class="btn btn-outline-success w-100">
                    Google Map
                </button>
            </a>
        </div>
        <?php if($data->status == 5 || $data->status == 6): ?>
        <div>
            <p class="text-body-secondary">Selesai</p>
        </div>
        <?php elseif(auth()->user()->akses_lvl == "2" && in_array($data->status, [4.1, 4.2, 4.3])): ?>
        <div>
            <p class="text-body-secondary">Menunggu UPTDKPP</p>
        </div>
        <?php else: ?>
        <div class="mb-2">
            <a href="/<?php echo e($nextUrl); ?>" class="text-decoration-none">
                <button type="button" class="btn btn-outline-success w-100">Lanjut</button>
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<script src="/js/pdfreader.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/tinjau.blade.php ENDPATH**/ ?>