

<?php $__env->startSection('container-user'); ?>
<!-- berhasil -->
<?php if(session()->has('berhasil')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <strong><?php echo e(session('berhasil')); ?> </strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<h2 class="my-3 text-center">Arsip Status Permohonan</h2>
<form class="" role="search" method="get" action="/dashboard/admin/arsip">
    <div class="row g-3 align-items-center">
        <div class="col-6">
            <input value="<?php echo e($filter[0]); ?>" name="query" class="form-control" type="search" placeholder="Cari NIK atau kode permohonan" aria-label="Cari NIK atau kode permohonan">
        </div>
        <div class="col-6">
            <select name="status" class="form-select" aria-label="Default select example">
                <option value="">Filter status</option>
                <?php if(auth()->user()->akses_lvl == 2): ?>
                <option value="0" <?php echo e($filter[1] == '0' ? 'selected' : ''); ?>>Data kurang lengkap/salah</option>
                <option value="1" <?php echo e($filter[1] == '1' ? 'selected' : ''); ?>>Menunggu diproses</option>
                <option value="2" <?php echo e($filter[1] == '2' ? 'selected' : ''); ?>>Sedang ditinjau</option>
                <option value="3" <?php echo e($filter[1] == '3' ? 'selected' : ''); ?>>Menunggu surat rekomendasi</option>
                <option value="4.1" <?php echo e(in_array($filter[1], ['4.1', '4.2']) ? 'selected' : ''); ?>>Sedang dilaksanakan</option>
                <option value="4.3" <?php echo e($filter[1] == '4.3' ? 'selected' : ''); ?>>Sedang dilaksanakan masyarakat</option>
                <option value="5" <?php echo e($filter[1] == '5' ? 'selected' : ''); ?>>Selesai</option>
                <option value="6" <?php echo e($filter[1] == '6' ? 'selected' : ''); ?>>Status jalan nasional/provinsi</option>
                <?php else: ?>
                <option value="4.2" <?php echo e($filter[1] == '4.2' ? 'selected' : ''); ?>>Sedang dilaksanakan</option>
                <option value="5" <?php echo e($filter[1] == '5' ? 'selected' : ''); ?>>Selesai</option>
                <?php endif; ?>

            </select>
        </div>
    </div>
    <div class="mt-3 row g-3 align-items-center">
        <div class="col-auto form-floating">
            <input type="date" name="start_date" class="form-control" id="Awal" value="<?php echo e($filter[2] ?? ''); ?>">
            <label for="Awal">Awal</label>
        </div>
        <div class="col-auto form-floating">
            <input type="date" name="end_date" class="form-control" id="Akhir" value="<?php echo e($filter[3] ?? ''); ?>">
            <label for="Akhir">Akhir</label>
        </div>
        <div class="col-auto">
            <select name="order_by" class="form-select">
                <option value="">Filter Terakhir di Ubah</option>
                <option value="asc" <?php echo e($filter[4] == 'asc' ? 'selected' : ''); ?>>Terlama</option>
                <option value="dsc" <?php echo e($filter[4] == 'dsc' ? 'selected' : ''); ?>>Terbaru</option>
            </select>
        </div>
        <div class="col-auto">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </div>
        <div class="col-auto">
            <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal">Hapus arsip data 1 bulan</button>
        </div>
    </div>
</form>

<!-- Modal -->
<div class="modal fade mt-5" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Penghapusan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus arsip data yang lebih dari 1 bulan?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form action="/dashboard/admin/hapus" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>



<div class="table-responsive">
    <div id="data-container">
        <?php echo $__env->make('users.admin.tabledatastatus', ['datas' => $datas], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/statusrekap.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/admin/backup.blade.php ENDPATH**/ ?>