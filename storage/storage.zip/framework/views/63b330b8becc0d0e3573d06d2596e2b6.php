<?php echo e($slot); ?>

<?php /**PATH D:\App\sistem-informasi-web\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>