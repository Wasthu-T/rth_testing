

<?php $__env->startSection('container'); ?>
<div class="modal modal-sheet position-static d-block " tabindex="-1" role="dialog" id="modalSignin">

    <?php if(session()->has('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        <strong><?php echo e(session('status')); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if(session()->has('loginError')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <strong><?php echo e(session('loginError')); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="modal-dialog" role="document">
        <div class="modal-content rounded-4 shadow">
            <div class="border-bottom-0 m-3">
                <h1 class="fw-bold mb-0 fs-2 text-center"><img src="/img/logo/simpel-rth-light-removebg-preview (1).png" alt="rth" width="50px" height="auto"> Lupa Password</h1>
            </div>

            <div class="modal-body pt-0">
                <form method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating my-3">
                        <input name="email" type="email" class="form-control rounded-3 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="example@gmail.com" autofocus required>
                        <label for="email">Email</label>
                    </div>
                    <?php if($errors->has('g-recaptcha-response')): ?>
                    <span class="help-block text-danger">
                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                    </span>
                    <?php endif; ?>
                    <div class="form-floating mb-3">
                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo NoCaptcha::display(); ?>

                    </div>
                    <button class="w-100 mb-2 btn btn-lg rounded-3 btn-success" type="submit"><i class="bi bi-envelope-fill"></i>Kirim Link Reset Password</button>
                    <div class="mb-3 justify-content-start d-flex">
                        <a href="/masuk" class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover" style="font-size: .9em;"><i class="bi bi-arrow-left"></i>Kembali ke Halaman Login</a>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('form.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/form/forgot-password.blade.php ENDPATH**/ ?>