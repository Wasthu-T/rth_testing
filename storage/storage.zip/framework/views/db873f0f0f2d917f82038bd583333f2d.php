

<?php $__env->startSection('container'); ?>
<div class="container">
    <?php if(session('resent')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <?php echo e(__('Tautan verifikasi baru telah dikirim ke alamat email Anda.')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php echo e(__('Sebelum melanjutkan, harap periksa email Anda untuk tautan verifikasi.')); ?>

    <?php echo e(__('Jika Anda tidak menerima email tersebut')); ?>,
    <form class="d-inline" method="POST" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('klik di sini untuk mengirim ulang')); ?></button>.
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('form.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/form/verify-email.blade.php ENDPATH**/ ?>