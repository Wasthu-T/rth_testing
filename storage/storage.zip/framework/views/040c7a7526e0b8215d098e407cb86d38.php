<div class="row gap-5 mx-3">
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klhn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-12 col-md-4 col-lg-3 mx-auto mx-lg-3">
        <?php if($klhn->ftphn): ?>
        <div class="" style="height: 150px; overflow:hidden;">
            <?php
            $filePath = asset('/' . $klhn->ftphn->ftphn);
            $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
            ?>
            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'])): ?>
            <img src="<?php echo e($filePath); ?>" class="card-img-top" alt="...">
            <?php elseif($fileExtension === 'pdf'): ?>
            <table style="height: 150px; width:100%;">
                <tbody>
                    <tr>
                        <td class="align-middle text-center">
                            <h5>Gambar Preview Tidak Tersedia</h5>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <table style="height: 150px;">
            <tbody>
                <tr>
                    <td class="align-middle text-center">
                        <h5>Gambar Preview Tidak Tersedia</h5>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php endif; ?>
        <hr>
        <div class="card-body">
            <h6>Kode :</h6>
            <h6 class="card-title"><?php echo e($klhn->slug); ?></h6>
            <div class="card-text"> Status :
                <?php if($klhn->status == 0): ?>
                <p class="text-danger">Data kurang lengkap/salah</p>
                <?php elseif($klhn->status == 1): ?>
                <p class="text-danger">Menunggu diproses</p>
                <?php elseif($klhn->status == 2): ?>
                <p class="text-primary">Sedang ditinjau</p>
                <?php elseif($klhn->status == 3): ?>
                <p class="text-primary">Menunggu surat rekomendasi</p>
                <?php elseif($klhn->status == 4.1 || $klhn->status == 4.2 || $klhn->status == 4.3): ?>
                <p class="text-primary">Sedang dilaksanakan</p>
                <?php elseif($klhn->status == 5): ?>
                <p class="text-success">Selesai</p>
                <?php elseif($klhn->status == 6): ?>
                <p class="text-primary">Status Jalan <?php echo e($klhn->istansi); ?></p>
                <p class="text-danger">Tidak dapat dilanjuti dikarenakan jalan <?php echo e($klhn->istansi); ?></p>
                <?php else: ?>
                <p class="text-danger">Error silahkan menghubungi admin</p>
                <?php endif; ?>
            </div>
            <p class="card-text">Alamat : </br><?php echo e($klhn->loc_phntts); ?></p>
        </div>
        <div class="card-text">
            <ul class="list-group list-group-flush">
                <li class="list-group-item text-truncate">Deskripsi : </br><?php echo e($klhn->alasan); ?></li>
                <li class="list-group-item text-truncate">Dibuat : </br><?php echo e($klhn->created_at->format('d/m/Y')); ?></li>
            </ul>
            <div class="gap-3 pb-3">
                <a href="/dashboard/<?php echo e($klhn->slug); ?>" class="btn btn-success ">Detail</a>
                <?php if($klhn->status == 1 || $klhn->status == 0): ?>
                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal" data-slug="<?php echo e($klhn->slug); ?>">
                    <i class="bi bi-trash"></i> Hapus
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- Modal -->
<div class="modal fade mt-5" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Penghapusan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus data ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>

                <form id="deleteForm" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="my-3">
    <?php echo e($datas->links()); ?>

</div>
<?php if($datas->count() === 0): ?>
<h6 class="text-danger">Data tidak ditemukan</h6>
<?php endif; ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var confirmDeleteModal = document.getElementById('confirmDeleteModal');
        confirmDeleteModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget; // Tombol yang memicu modal
            var slug = button.getAttribute('data-slug'); // Ambil slug dari tombol
            var deleteForm = document.getElementById('deleteForm');
            deleteForm.action = "/dashboard/arsip/" + slug;
        });
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH D:\App\sistem-informasi-web\resources\views/users/user/tabledatastatus.blade.php ENDPATH**/ ?>