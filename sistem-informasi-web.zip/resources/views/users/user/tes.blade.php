@foreach($data as $data)

{{ $data->ftphn }}

@endforeach