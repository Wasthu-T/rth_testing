<footer class="py-3 bg-success">
  <div class="container">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="/beranda" class="nav-link px-2 text-white">Beranda</a></li>
      <li class="nav-item"><a href="/profil" class="nav-link px-2 text-white">Profil</a></li>
      <li class="nav-item"><a href="/kontak" class="nav-link px-2 text-white">Kontak</a></li>
    </ul>
    <p class="text-center text-body-secondary">© 2024 Simpel RTH</p>
  </div>
</footer>
